### Dark purple/black theme based on the sweet theme.
